<?php
$GLOBALS['wpmdb_meta']['wp-migrate-db-pro-cli']['version'] = '1.2.2';
$GLOBALS['wpmdb_meta']['wp-migrate-db-pro-cli']['required-php-version'] = '5.3.2';
